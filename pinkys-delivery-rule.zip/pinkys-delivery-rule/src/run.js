// Reads the cooler-bag choice ("Fulfillment" cart attribute) and hides the
// opposite method so checkout lands on the right tab.
export function run(input) {
  const choice = input.cart.attribute?.value;
  const hideTypes =
    choice === "Local delivery" ? ["PICK_UP", "PICKUP_POINT"] :
    choice === "Pick up" ? ["LOCAL"] : [];
  const operations = [];
  for (const group of input.cart.deliveryGroups) {
    for (const opt of group.deliveryOptions) {
      if (hideTypes.includes(opt.deliveryMethodType)) {
        operations.push({ hide: { deliveryOptionHandle: opt.handle } });
      }
    }
  }
  return { operations };
}
