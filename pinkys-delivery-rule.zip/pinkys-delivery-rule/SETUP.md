# Pinky's checkout rule — setup (about 20 minutes, one time)

What it does: "Local delivery" in the cooler bag hides Pickup, so checkout opens straight on Ship.
"Pick up" hides Local delivery. Merch shipping is never touched.

1. Install Node.js 20+ (nodejs.org) and open Terminal.
2. Run: npm init @shopify/app@latest   -> name it "pinkys-checkout", choose "Build an extension-only app".
3. cd pinkys-checkout
4. Run: shopify app generate extension --template delivery_customization --flavor vanilla-js
   Name it: pinkys-fulfillment-choice
5. Replace the files in extensions/pinkys-fulfillment-choice/ with the ones in this folder
   (shopify.extension.toml, src/run.graphql, src/run.js). Delete any other src/*.js test files if they error.
6. Run: shopify app deploy   (log in as the store owner, pick Pinky's store, confirm release)
7. Run: shopify app dev   -> press "g" to open GraphiQL, then run:
     query { shopifyFunctions(first: 10) { nodes { id title } } }
   Copy the id for "Pinky's fulfillment choice", then run:
     mutation { deliveryCustomizationCreate(deliveryCustomization: {
       functionId: "PASTE_ID", title: "Pinky's fulfillment choice", enabled: true
     }) { deliveryCustomization { id } userErrors { message } } }
8. Install the app on the store when prompted. Then turn off the old Shipy rules (or uninstall Shipy).
9. Test: cooler bag -> Local delivery -> checkout shows only Ship. Cooler bag -> Pick up -> no Local delivery.
